#!/bin/bash
echo "Decrypted Successfully!"
